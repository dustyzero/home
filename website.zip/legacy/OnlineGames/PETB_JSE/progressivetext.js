// we will need to write an engine for progressively rendering text. this one displays questions!
async function DisplayQ(Q) {
    var finalQ = Q;
    
}